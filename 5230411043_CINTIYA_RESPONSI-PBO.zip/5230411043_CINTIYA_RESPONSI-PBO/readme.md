NAMA: CINTIYA
NPM: 5230411043

Aplikasi ini adalah sebuah sistem manajemen retail berbasis Python dengan antarmuka grafis yang dibuat menggunakan Tkinter. Aplikasi ini terintegrasi dengan database MySQL untuk menyimpan dan mengelola data produk serta transaksi. Berikut adalah deskripsi fitur dan fungsionalitas aplikasi:
1. Komponen Utama
Database Class
Mengelola koneksi dan operasi terhadap database MySQL, termasuk menambahkan, membaca, memperbarui, dan menghapus data produk dan transaksi.

Metode yang tersedia:

insert_produk(nama, harga): Menambah produk baru ke tabel produk.
get_produk(): Mengambil daftar semua produk dari database.
update_produk(id_produk, nama, harga): Memperbarui data produk berdasarkan ID produk.
delete_produk(id_produk): Menghapus produk berdasarkan ID produk.
insert_transaksi(id_produk, jumlah, total): Menambahkan data transaksi ke tabel transaksi.
close(): Menutup koneksi ke database.
Produk Class
Merepresentasikan objek produk dengan atribut ID produk, nama produk, dan harga produk.

Aplikasi Class
Mengatur antarmuka pengguna dan interaksi dengan database. Menggunakan widget dari Tkinter untuk mengelola produk dan transaksi.

2. Fitur Aplikasi
Manajemen Produk
Tambah Produk

Memasukkan nama dan harga produk melalui input teks.
Menyimpan data ke database.
Menggunakan tombol "Tambah Produk" untuk menambahkan produk baru.
Update Produk

Memilih produk dari daftar drop-down.
Menampilkan nama dan harga produk yang dipilih di form input.
Memperbarui data di database setelah perubahan disimpan.
Hapus Produk

Memilih produk dari daftar drop-down.
Menghapus produk berdasarkan ID dari database.
Transaksi
Pilih Produk untuk Transaksi

Daftar produk ditampilkan dalam widget Combobox.
Pengguna memilih produk yang akan ditransaksikan.
Masukkan Jumlah Produk

Input jumlah produk yang akan dibeli.
Simpan Transaksi

Menghitung total harga berdasarkan jumlah dan harga produk.
Menyimpan data transaksi ke database dengan informasi tanggal dan waktu transaksi.
3. Fitur Tambahan
Validasi Input

Memastikan nama produk tidak kosong.
Harga produk harus berupa angka valid.
Jumlah produk harus lebih dari 0.
Notifikasi dan Pesan Kesalahan

Menggunakan messagebox untuk memberikan notifikasi kepada pengguna jika terjadi kesalahan (misalnya, input tidak valid atau kesalahan koneksi database).
4. Alur Kerja
Pengguna membuka aplikasi.
Pada bagian Manajemen Produk:
Menambah, memperbarui, atau menghapus data produk.
Data produk diperbarui di daftar drop-down.
Pada bagian Transaksi:
Pengguna memilih produk, memasukkan jumlah, dan menyimpan transaksi.
Semua data disimpan dan dikelola di database MySQL.
Teknologi yang Digunakan
Python untuk logika aplikasi dan GUI.
Tkinter untuk antarmuka grafis.
MySQL Connector untuk komunikasi dengan database.
MySQL sebagai database relasional.
Aplikasi ini cocok digunakan untuk toko kecil atau bisnis retail yang memerlukan pencatatan produk dan transaksi sederhana.

Berikut adalah langkah-langkah untuk menjalankan aplikasi manajemen retail berbasis Python ini:

1. Persyaratan Awal
Sebelum menjalankan aplikasi, pastikan Anda telah memenuhi persyaratan berikut:

Python telah diinstal di komputer Anda. Disarankan menggunakan Python versi 3.8 atau lebih baru.
MySQL Server telah diinstal, dan Anda memiliki akses ke database MySQL.
MySQL Connector for Python telah diinstal. Anda dapat menginstalnya menggunakan perintah berikut:
bash
Copy code
pip install mysql-connector-python
2. Persiapan Database
Buat Database Baru
Pastikan Anda telah membuat database dengan nama retail_db di MySQL.
Jika belum, jalankan perintah berikut di MySQL:

sql
Copy code
CREATE DATABASE retail_db;
USE retail_db;
Buat Tabel
Buat tabel yang diperlukan untuk menyimpan data produk dan transaksi. Jalankan perintah SQL berikut:

sql
Copy code
CREATE TABLE produk (
    id_produk INT AUTO_INCREMENT PRIMARY KEY,
    nama_produk VARCHAR(255) NOT NULL,
    harga_produk DECIMAL(10, 2) NOT NULL
);

CREATE TABLE transaksi (
    id_transaksi INT AUTO_INCREMENT PRIMARY KEY,
    id_produk INT NOT NULL,
    jumlah_produk INT NOT NULL,
    total_harga DECIMAL(10, 2) NOT NULL,
    tanggal_transaksi DATETIME NOT NULL,
    FOREIGN KEY (id_produk) REFERENCES produk(id_produk)
);
3. Konfigurasi Kode Python
Pastikan Database Terhubung
Pada bagian kelas Database dalam kode Python, periksa dan sesuaikan parameter koneksi database:

python
Copy code
self.conn = mysql.connector.connect(
    host="localhost",  # Ganti dengan alamat server jika bukan localhost
    user="root",       # Ganti dengan nama pengguna MySQL Anda
    password="",       # Ganti dengan password MySQL Anda
    database="retail_db"  # Pastikan sesuai dengan nama database yang telah dibuat
)
Simpan dan Jalankan Script
Simpan kode Python ke file, misalnya app.py.

4. Menjalankan Aplikasi
Buka Terminal atau Command Prompt
Arahkan direktori kerja ke lokasi file app.py yang disimpan.

Jalankan Script
Jalankan aplikasi dengan perintah berikut:

bash
Copy code
python app.py
5. Menggunakan Aplikasi
Tambah Produk

Masukkan nama dan harga produk di bagian "Manajemen Produk".
Klik tombol "Tambah Produk".
Kelola Produk

Pilih produk dari daftar drop-down untuk mengedit atau menghapusnya.
Klik "Update Produk" untuk mengubah data.
Klik "Hapus Produk" untuk menghapus produk dari database.
Simpan Transaksi

Pilih produk dari daftar drop-down.
Masukkan jumlah produk yang dibeli.
Klik tombol "Simpan Transaksi" untuk menyimpan data transaksi.
6. Penutupan Aplikasi
Setelah selesai, tutup aplikasi dengan menutup jendela GUI.
Koneksi ke database akan ditutup secara otomatis oleh metode close().
Jika Anda mengalami kendala selama proses, pastikan memeriksa error pada terminal atau memastikan koneksi database MySQL berjalan dengan baik.


Berikut adalah penjelasan struktur database retail_db yang digunakan dalam aplikasi manajemen retail ini:

1. Tabel produk
Tabel ini digunakan untuk menyimpan data produk yang dikelola dalam aplikasi.

Kolom	Tipe Data	Deskripsi
id_produk	INT AUTO_INCREMENT PRIMARY KEY	Primary key unik untuk setiap produk.
nama_produk	VARCHAR(255)	Nama produk, berupa string maksimal 255 karakter.
harga_produk	DECIMAL(10, 2)	Harga produk dengan 2 desimal untuk akurasi.
Contoh Data Tabel produk:
id_produk	nama_produk	harga_produk
1	Sabun Cuci Piring	15000.00
2	Pasta Gigi	20000.00
2. Tabel transaksi
Tabel ini digunakan untuk mencatat semua transaksi yang dilakukan.

Kolom	Tipe Data	Deskripsi
id_transaksi	INT AUTO_INCREMENT PRIMARY KEY	Primary key unik untuk setiap transaksi.
id_produk	INT	Foreign key yang mengacu ke id_produk di tabel produk.
jumlah_produk	INT	Jumlah produk yang dibeli dalam transaksi.
total_harga	DECIMAL(10, 2)	Total harga untuk transaksi (jumlah_produk × harga_produk).
tanggal_transaksi	DATETIME	Waktu ketika transaksi dilakukan.
Contoh Data Tabel transaksi:
id_transaksi	id_produk	jumlah_produk	total_harga	tanggal_transaksi
1	1	3	45000.00	2024-12-31 10:30:00
2	2	2	40000.00	2024-12-31 12:15:00
Hubungan Antar Tabel
Relasi:

Tabel transaksi memiliki kolom id_produk yang menjadi foreign key dan merujuk ke kolom id_produk di tabel produk.
Hal ini memastikan bahwa setiap transaksi hanya dapat mencatat produk yang terdaftar di tabel produk.
Jenis Relasi:

One-to-Many: Satu produk (produk) dapat muncul di banyak transaksi (transaksi).
ERD (Entity Relationship Diagram)
lua
Copy code
+-------------------+         +---------------------+
|     produk        |         |      transaksi      |
+-------------------+         +---------------------+
| id_produk (PK)    | <---+   | id_transaksi (PK)   |
| nama_produk       |      +--- id_produk (FK)     |
| harga_produk      |          | jumlah_produk      |
+-------------------+          | total_harga        |
                               | tanggal_transaksi  |
                               +---------------------+
Keuntungan Struktur Ini
Relasional: Memisahkan data produk dan transaksi memastikan fleksibilitas serta integritas data.
Efisiensi: Harga produk disimpan satu kali di tabel produk, mengurangi redundansi.
Skalabilitas: Struktur ini dapat dengan mudah diperluas dengan tabel tambahan, seperti pelanggan atau kategori_produk.
Struktur ini mendukung kebutuhan aplikasi untuk manajemen produk dan pencatatan transaksi dengan cara yang terorganisir.























