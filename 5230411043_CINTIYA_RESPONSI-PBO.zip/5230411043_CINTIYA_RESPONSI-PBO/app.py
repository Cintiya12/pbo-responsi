import tkinter as tk
from tkinter import messagebox, ttk
import mysql.connector
from datetime import datetime

class Database:
    def __init__(self):
        try:
            self.conn = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",  # Sesuaikan password
                database="retail_db"
            )
            self.cursor = self.conn.cursor()  # Menyimpan cursor untuk eksekusi query
            print("Koneksi berhasil!")
        except mysql.connector.Error as err:
            print(f"Terjadi kesalahan: {err}")  # Menambahkan print untuk kesalahan
            messagebox.showerror("Database Error", f"Terjadi kesalahan: {err}")

    def insert_produk(self, nama, harga):
        try:
            self.cursor.execute("INSERT INTO produk (nama_produk, harga_produk) VALUES (%s, %s)", (nama, harga))
            self.conn.commit()
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", f"Error inserting product: {err}")

    def get_produk(self):
        try:
            self.cursor.execute("SELECT * FROM produk")
            return self.cursor.fetchall()
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", f"Error fetching products: {err}")
            return []

    def update_produk(self, id_produk, nama, harga):
        try:
            self.cursor.execute("UPDATE produk SET nama_produk = %s, harga_produk = %s WHERE id_produk = %s", (nama, harga, id_produk))
            self.conn.commit()
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", f"Error updating product: {err}")

    def delete_produk(self, id_produk):
        try:
            self.cursor.execute("DELETE FROM produk WHERE id_produk = %s", (id_produk,))
            self.conn.commit()
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", f"Error deleting product: {err}")

    def insert_transaksi(self, id_produk, jumlah, total):
        try:
            self.cursor.execute("INSERT INTO transaksi (id_produk, jumlah_produk, total_harga, tanggal_transaksi) VALUES (%s, %s, %s, %s)", 
                                (id_produk, jumlah, total, datetime.now()))
            self.conn.commit()
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", f"Error inserting transaction: {err}")

    def close(self):
        self.cursor.close()
        self.conn.close()

class Produk:
    def __init__(self, id_produk, nama_produk, harga_produk):
        self.id_produk = id_produk
        self.nama_produk = nama_produk
        self.harga_produk = harga_produk

class Aplikasi:
    def __init__(self, root):
        self.root = root
        self.root.title("Aplikasi Manajemen Retail")
        self.db = Database()

        print("Inisialisasi aplikasi...")
        self.create_widgets()
        self.load_produk()

    def create_widgets(self):
        # Manajemen Produk
        self.label_nama = tk.Label(self.root, text="Nama Produk:")
        self.label_nama.grid(row=0, column=0, padx=10, pady=10)
        self.entry_nama = tk.Entry(self.root)
        self.entry_nama.grid(row=0, column=1, padx=10, pady=10)

        self.label_harga = tk.Label(self.root, text="Harga Produk:")
        self.label_harga.grid(row=1, column=0, padx=10, pady=10)
        self.entry_harga = tk.Entry(self.root)
        self.entry_harga.grid(row=1, column=1, padx=10, pady=10)

        self.button_tambah = tk.Button(self.root, text="Tambah Produk", command=self.tambah_produk)
        self.button_tambah.grid(row=2, columnspan=2, pady=10)

        # Transaksi
        self.label_produk = tk.Label(self.root, text="Pilih Produk:")
        self.label_produk.grid(row=3, column=0, padx=10, pady=10)
        self.combo_produk = ttk.Combobox(self.root)
        self.combo_produk.grid(row=3, column=1, padx=10, pady=10)

        self.label_jumlah = tk.Label(self.root, text="Jumlah:")
        self.label_jumlah.grid(row=4, column=0, padx=10, pady=10)
        self.entry_jumlah = tk.Entry(self.root)
        self.entry_jumlah.grid(row=4, column=1, padx=10, pady=10)

        self.button_transaksi = tk.Button(self.root, text="Simpan Transaksi", command=self.simpan_transaksi)
        self.button_transaksi.grid(row=5, columnspan=2, pady=10)

        self.label_total = tk.Label(self.root, text="Total Harga:")
        self.label_total.grid(row=6, column=0, padx=10, pady=10)
        self.label_total_harga = tk.Label(self.root, text="0")
        self.label_total_harga.grid(row=6, column=1, padx=10, pady=10)

        # Button Update and Delete
        self.button_update = tk.Button(self.root, text="Update Produk", command=self.update_produk)
        self.button_update.grid(row=7, column=0, padx=10, pady=10)

        self.button_delete = tk.Button(self.root, text="Hapus Produk", command=self.delete_produk)
        self.button_delete.grid(row=7, column=1, padx=10, pady=10)

        self.combo_produk.bind("<<ComboboxSelected>>", self.update_total)

    def load_produk(self):
        try:
            produk_list = self.db.get_produk()
            if produk_list:
                self.combo_produk['values'] = [f"{p[0]} - {p[1]}" for p in produk_list]
            else:
                self.combo_produk['values'] = []
        except Exception as e:
            messagebox.showerror("Error", f"Error loading products: {e}")

    def tambah_produk(self):
        nama = self.entry_nama.get()
        harga = self.entry_harga.get()

        if not nama or not harga:
            messagebox.showerror("Error", "Nama dan Harga produk harus diisi.")
            return

        try:
            harga = float(harga)
            self.db.insert_produk(nama, harga)
            messagebox.showinfo("Sukses", "Produk berhasil ditambahkan.")
            self.load_produk()  # Refresh daftar produk
            self.entry_nama.delete(0, tk.END)
            self.entry_harga.delete(0, tk.END)
        except ValueError:
            messagebox.showerror("Error", "Harga harus berupa angka.")

    def update_total(self, event):
        selected_item = self.combo_produk.get()
        if selected_item:
            produk_id = selected_item.split(" - ")[0]  # Ambil ID produk dari string
            produk = self.db.get_produk()
            for p in produk:
                if str(p[0]) == produk_id:
                    self.label_total_harga.config(text=f"{p[2]:.2f}")  # Update total harga
                    break

    def simpan_transaksi(self):
        selected_item = self.combo_produk.get()
        jumlah = self.entry_jumlah.get()

        if not selected_item or not jumlah:
            messagebox.showerror("Error", "Produk dan Jumlah harus diisi.")
            return

        try:
            jumlah = int(jumlah)
            if jumlah <= 0:
                raise ValueError("Jumlah harus lebih dari 0.")

            produk_id = selected_item.split(" - ")[0]  # Ambil ID produk dari string
            total_harga = float(self.label_total_harga.cget("text")) * jumlah

            self.db.insert_transaksi(produk_id, jumlah, total_harga)
            messagebox.showinfo("Sukses", "Transaksi berhasil disimpan.")
            self.entry_jumlah.delete(0, tk.END)
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    def update_produk(self):
        selected_item = self.combo_produk.get()
        if selected_item:
            produk_id = selected_item.split(" - ")[0]  # Ambil ID produk dari string
            produk = self.db.get_produk()
            for p in produk:
                if str(p[0]) == produk_id:
                    self.entry_nama.delete(0, tk.END)
                    self.entry_nama.insert(0, p[1])  # Nama produk
                    self.entry_harga.delete(0, tk.END)
                    self.entry_harga.insert(0, p[2])  # Harga produk
                    break

            def confirm_update():
                nama = self.entry_nama.get()
                harga = self.entry_harga.get()

                if not nama or not harga:
                    messagebox.showerror("Error", "Nama dan Harga produk harus diisi.")
                    return

                try:
                    harga = float(harga)
                    self.db.update_produk(produk_id, nama, harga)
                    messagebox.showinfo("Sukses", "Produk berhasil diupdate.")
                    self.load_produk()  # Refresh daftar produk
                    self.entry_nama.delete(0, tk.END)
                    self.entry_harga.delete(0, tk.END)
                except ValueError:
                    messagebox.showerror("Error", "Harga harus berupa angka.")
            
            # Konfirmasi update
            if messagebox.askyesno("Konfirmasi", "Apakah Anda yakin ingin mengupdate produk ini?"):
                confirm_update()

    def delete_produk(self):
        selected_item = self.combo_produk.get()
        if selected_item:
            produk_id = selected_item.split(" - ")[0]  # Ambil ID produk dari string
            if messagebox.askyesno("Konfirmasi", "Apakah Anda yakin ingin menghapus produk ini?"):
                self.db.delete_produk(produk_id)
                messagebox.showinfo("Sukses", "Produk berhasil dihapus.")
                self.load_produk()  # Refresh daftar produk
        else:
            messagebox.showerror("Error", "Pilih produk yang ingin dihapus.")

    def run(self):
        self.root.mainloop()
        self.db.close()

if __name__ == "__main__":
    root = tk.Tk()
    app = Aplikasi(root)
    app.run()
